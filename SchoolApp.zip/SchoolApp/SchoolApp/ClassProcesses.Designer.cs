﻿namespace SchoolApp
{
    partial class ClassProcesses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            label4 = new Label();
            label5 = new Label();
            comboBox1 = new ComboBox();
            button2 = new Button();
            comboBox2 = new ComboBox();
            label6 = new Label();
            label7 = new Label();
            comboBox3 = new ComboBox();
            label8 = new Label();
            label9 = new Label();
            comboBox4 = new ComboBox();
            button3 = new Button();
            label10 = new Label();
            comboBox5 = new ComboBox();
            button4 = new Button();
            label11 = new Label();
            listBox1 = new ListBox();
            button5 = new Button();
            label12 = new Label();
            comboBox6 = new ComboBox();
            listBox2 = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(312, 9);
            label1.Name = "label1";
            label1.Size = new Size(123, 15);
            label1.TabIndex = 0;
            label1.Text = "Sınıf İşlemleri Menüsü";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(94, 48);
            label2.Name = "label2";
            label2.Size = new Size(119, 15);
            label2.TabIndex = 1;
            label2.Text = "Sınıf Oluşturma Alanı";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 91);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 2;
            label3.Text = "Sınıf Adı : ";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(104, 82);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 3;
            // 
            // button1
            // 
            button1.Location = new Point(76, 183);
            button1.Name = "button1";
            button1.Size = new Size(84, 23);
            button1.TabIndex = 4;
            button1.Text = "Sınıf Oluştur";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(327, 44);
            label4.Name = "label4";
            label4.Size = new Size(101, 15);
            label4.TabIndex = 5;
            label4.Text = "Ders Ekleme Alanı";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(275, 119);
            label5.Name = "label5";
            label5.Size = new Size(78, 15);
            label5.TabIndex = 6;
            label5.Text = "Ders Seçiniz : ";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(377, 119);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 7;
            // 
            // button2
            // 
            button2.Location = new Point(352, 163);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 8;
            button2.Text = "Ders Ekle";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(117, 121);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(10, 129);
            label6.Name = "label6";
            label6.Size = new Size(101, 15);
            label6.TabIndex = 10;
            label6.Text = "Rehber Öğretmen";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(278, 78);
            label7.Name = "label7";
            label7.Size = new Size(78, 15);
            label7.TabIndex = 11;
            label7.Text = "Sınıf Seçiniz : ";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(377, 70);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(121, 23);
            comboBox3.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(597, 44);
            label8.Name = "label8";
            label8.Size = new Size(92, 15);
            label8.TabIndex = 5;
            label8.Text = "Ders Silme Alanı";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(545, 119);
            label9.Name = "label9";
            label9.Size = new Size(78, 15);
            label9.TabIndex = 6;
            label9.Text = "Ders Seçiniz : ";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(647, 119);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(121, 23);
            comboBox4.TabIndex = 7;
            // 
            // button3
            // 
            button3.Location = new Point(622, 163);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 8;
            button3.Text = "Ders Sil";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(548, 78);
            label10.Name = "label10";
            label10.Size = new Size(78, 15);
            label10.TabIndex = 11;
            label10.Text = "Sınıf Seçiniz : ";
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Location = new Point(647, 70);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(121, 23);
            comboBox5.TabIndex = 12;
            // 
            // button4
            // 
            button4.Location = new Point(658, 400);
            button4.Name = "button4";
            button4.Size = new Size(130, 23);
            button4.TabIndex = 13;
            button4.Text = "Listeleri Güncelle";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(22, 228);
            label11.Name = "label11";
            label11.Size = new Size(65, 15);
            label11.TabIndex = 14;
            label11.Text = "Sınıf Listesi";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(34, 256);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(145, 124);
            listBox1.TabIndex = 15;
            // 
            // button5
            // 
            button5.Location = new Point(129, 386);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 16;
            button5.Text = "Güncelle";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(258, 228);
            label12.Name = "label12";
            label12.Size = new Size(65, 15);
            label12.TabIndex = 17;
            label12.Text = "Ders Listesi";
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Location = new Point(258, 256);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(121, 23);
            comboBox6.TabIndex = 18;
            comboBox6.SelectedIndexChanged += comboBox6_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(259, 286);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(120, 94);
            listBox2.TabIndex = 19;
            // 
            // ClassProcesses
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBox2);
            Controls.Add(comboBox6);
            Controls.Add(label12);
            Controls.Add(button5);
            Controls.Add(listBox1);
            Controls.Add(label11);
            Controls.Add(button4);
            Controls.Add(comboBox5);
            Controls.Add(comboBox3);
            Controls.Add(label10);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(comboBox2);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(comboBox4);
            Controls.Add(comboBox1);
            Controls.Add(label9);
            Controls.Add(label5);
            Controls.Add(label8);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ClassProcesses";
            Text = "ClassProcesses";
            Load += ClassProcesses_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private Button button1;
        private Label label4;
        private Label label5;
        private ComboBox comboBox1;
        private Button button2;
        private ComboBox comboBox2;
        private Label label6;
        private Label label7;
        private ComboBox comboBox3;
        private Label label8;
        private Label label9;
        private ComboBox comboBox4;
        private Button button3;
        private Label label10;
        private ComboBox comboBox5;
        private Button button4;
        private Label label11;
        private ListBox listBox1;
        private Button button5;
        private Label label12;
        private ComboBox comboBox6;
        private ListBox listBox2;
    }
}